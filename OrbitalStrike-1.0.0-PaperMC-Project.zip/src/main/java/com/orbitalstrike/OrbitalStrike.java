package com.orbitalstrike;

import org.bukkit.*;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.FishHook;
import org.bukkit.entity.Player;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class OrbitalStrike extends JavaPlugin implements Listener, CommandExecutor, TabCompleter {

    public static final NamespacedKey STRIKE_TYPE_KEY = new NamespacedKey("orbitalstrike", "strike_type");
    public static final NamespacedKey RING_COUNT_KEY = new NamespacedKey("orbitalstrike", "ring_count");

    @Override
    public void onEnable() {
        getServer().getPluginManager().registerEvents(this, this);
        if (getCommand("orbital") != null) {
            getCommand("orbital").setExecutor(this);
            getCommand("orbital").setTabCompleter(this);
        }
        getLogger().info("OrbitalStrike 1.0.0 enabled successfully!");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("orbitalstrike.use")) {
            sender.sendMessage(ChatColor.RED + "คุณไม่มีสิทธิ์ใช้คำสั่งนี้!");
            return true;
        }

        // Usage: /orbital [nuke/stab] give [amount] [ring]
        if (args.length < 2) {
            sender.sendMessage(ChatColor.RED + "วิธีใช้: /orbital [nuke/stab] give [amount] [rings]");
            return true;
        }

        String mode = args[0].toLowerCase();
        if (!mode.equals("nuke") && !mode.equals("stab")) {
            sender.sendMessage(ChatColor.RED + "โหมดต้องเป็น 'nuke' หรือ 'stab'");
            return true;
        }

        if (!args[1].equalsIgnoreCase("give")) {
            sender.sendMessage(ChatColor.RED + "คำสั่งย่อยต้องเป็น 'give'");
            return true;
        }

        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "คำสั่งนี้ต้องพิมพ์โดยผู้เล่นในเกมเท่านั้น");
            return true;
        }

        Player player = (Player) sender;
        int amount = 1;
        int rings = 10;

        if (args.length >= 3) {
            try {
                amount = Math.max(1, Integer.parseInt(args[2]));
            } catch (NumberFormatException e) {
                sender.sendMessage(ChatColor.RED + "จำนวนไอเทมไม่ถูกต้อง กำหนดเป็น 1");
            }
        }

        if (args.length >= 4) {
            try {
                rings = Math.max(1, Math.min(25, Integer.parseInt(args[3])));
            } catch (NumberFormatException e) {
                sender.sendMessage(ChatColor.RED + "จำนวนวงแหวนไม่ถูกต้อง กำหนดเป็นค่าเริ่มต้น (10)");
            }
        }

        ItemStack rod = createStrikeRod(mode, amount, rings);
        player.getInventory().addItem(rod);
        player.sendMessage(ChatColor.GOLD + "[OrbitalStrike] " + ChatColor.GREEN + "ได้รับคันเบ็ด " +
                (mode.equals("nuke") ? "§c§lNuke Shot" : "§b§lStab Shot") + " §aจำนวน " + amount + " ชิ้น! (Rings: " + rings + ")");
        return true;
    }

    private ItemStack createStrikeRod(String mode, int amount, int rings) {
        ItemStack rod = new ItemStack(Material.FISHING_ROD, amount);
        ItemMeta meta = rod.getItemMeta();
        if (meta != null) {
            PersistentDataContainer pdc = meta.getPersistentDataContainer();
            pdc.set(STRIKE_TYPE_KEY, PersistentDataType.STRING, mode);
            pdc.set(RING_COUNT_KEY, PersistentDataType.INTEGER, rings);

            List<String> lore = new ArrayList<>();
            lore.add("");
            if (mode.equals("nuke")) {
                meta.setDisplayName(ChatColor.DARK_RED + "✦ " + ChatColor.RED + "Orbital Cannon: " + ChatColor.GOLD + "NUKE SHOT");
                lore.add(ChatColor.GRAY + "โหมด: " + ChatColor.RED + "Nuke Cluster Strike");
                lore.add(ChatColor.GRAY + "รัศมีวงแหวน: " + ChatColor.YELLOW + rings + " วงระเบิด TNT");
                lore.add(ChatColor.GRAY + "สถานะ: " + ChatColor.DARK_PURPLE + "ระเบิดสลายคันเบ็ดเมื่อยิงออก");
            } else {
                meta.setDisplayName(ChatColor.DARK_AQUA + "✦ " + ChatColor.AQUA + "Orbital Cannon: " + ChatColor.BLUE + "STAB SHOT");
                lore.add(ChatColor.GRAY + "โหมด: " + ChatColor.AQUA + "Vertical Pillar Strike");
                lore.add(ChatColor.GRAY + "แนวยิง: " + ChatColor.YELLOW + "Y=120 ลงไปถึง Y=-58");
                lore.add(ChatColor.GRAY + "สถานะ: " + ChatColor.DARK_PURPLE + "ลำแสงทำลายทะลวงความลึก");
            }
            lore.add("");
            lore.add(ChatColor.YELLOW + "⚡ คลิกขวาเพื่อยิง Orbital Strike ไปยังเป้าหมาย!");

            meta.setLore(lore);
            meta.setUnbreakable(false);
            meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
            rod.setItemMeta(meta);
        }
        return rod;
    }

    @EventHandler
    public void onFish(PlayerFishEvent event) {
        // Trigger on casting or reeling
        Player player = event.getPlayer();
        ItemStack item = player.getInventory().getItemInMainHand();
        if (item.getType() != Material.FISHING_ROD) {
            item = player.getInventory().getItemInOffHand();
        }
        if (item.getType() != Material.FISHING_ROD || !item.hasItemMeta()) {
            return;
        }

        PersistentDataContainer pdc = item.getItemMeta().getPersistentDataContainer();
        if (!pdc.has(STRIKE_TYPE_KEY, PersistentDataType.STRING)) {
            return;
        }

        String type = pdc.get(STRIKE_TYPE_KEY, PersistentDataType.STRING);
        int rings = pdc.getOrDefault(RING_COUNT_KEY, PersistentDataType.INTEGER, 10);

        if (event.getState() == PlayerFishEvent.State.FISHING) {
            FishHook hook = event.getHook();
            Location hookLoc = hook.getLocation();

            // Destroy the rod immediately upon firing
            item.setAmount(item.getAmount() - 1);
            player.playSound(player.getLocation(), Sound.ENTITY_ITEM_BREAK, 1.0f, 0.8f);
            player.spawnParticle(Particle.ITEM_SNOWBALL, player.getLocation().add(0, 1, 0), 25, 0.3, 0.3, 0.3, 0.1);

            // Execute attack at target trajectory
            if ("nuke".equalsIgnoreCase(type)) {
                executeNukeStrike(player, hook, rings);
            } else if ("stab".equalsIgnoreCase(type)) {
                executeStabStrike(player, hook);
            }
        }
    }

    private void executeNukeStrike(Player player, FishHook hook, int rings) {
        // Track the projectile or wait until impact / fixed delay
        new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                ticks++;
                if (hook.isDead() || !hook.isValid() || hook.isOnGround() || ticks >= 40) {
                    Location target = hook.getLocation();
                    spawnNukeCluster(target, rings);
                    hook.remove();
                    cancel();
                }
            }
        }.runTaskTimer(this, 1L, 1L);
    }

    private void spawnNukeCluster(Location center, int rings) {
        World world = center.getWorld();
        if (world == null) return;

        world.playSound(center, Sound.ENTITY_WITHER_SPAWN, 3.0f, 0.6f);
        world.spawnParticle(Particle.EXPLOSION_EMITTER, center, 5);

        // Spawn concentric circles of TNT (default 10 rings)
        for (int r = 1; r <= rings; r++) {
            final double radius = r * 2.2;
            final int tntCount = Math.max(6, r * 4);
            final int delay = r * 2; // Staggered explosion rings

            new BukkitRunnable() {
                @Override
                public void run() {
                    for (int i = 0; i < tntCount; i++) {
                        double angle = 2 * Math.PI * i / tntCount;
                        double x = center.getX() + radius * Math.cos(angle);
                        double z = center.getZ() + radius * Math.sin(angle);
                        Location spawnLoc = new Location(world, x, center.getY() + 1.5, z);

                        TNTPrimed tnt = world.spawn(spawnLoc, TNTPrimed.class);
                        tnt.setFuseTicks(25 + delay);
                        // Outward propulsion vector
                        Vector velocity = new Vector(Math.cos(angle) * 0.45, 0.35, Math.sin(angle) * 0.45);
                        tnt.setVelocity(velocity);

                        world.spawnParticle(Particle.FLAME, spawnLoc, 3, 0.1, 0.1, 0.1, 0.05);
                    }
                    world.playSound(center, Sound.ENTITY_TNT_PRIMED, 2.0f, 1.2f);
                }
            }.runTaskLater(this, delay);
        }
    }

    private void executeStabStrike(Player player, FishHook hook) {
        new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                ticks++;
                if (hook.isDead() || !hook.isValid() || hook.isOnGround() || ticks >= 40) {
                    Location target = hook.getLocation();
                    spawnStabPillar(target);
                    hook.remove();
                    cancel();
                }
            }
        }.runTaskTimer(this, 1L, 1L);
    }

    private void spawnStabPillar(Location target) {
        World world = target.getWorld();
        if (world == null) return;

        world.playSound(target, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 5.0f, 0.5f);
        world.strikeLightningEffect(target);

        // Explode vertically down from Y=120 down to Y=-58
        final int startY = 120;
        final int endY = -58;
        final int step = 4; // Spawn TNT every 4 blocks vertically

        new BukkitRunnable() {
            int currentY = startY;

            @Override
            public void run() {
                if (currentY < endY) {
                    cancel();
                    return;
                }

                for (int i = 0; i < 3; i++) {
                    if (currentY < endY) break;
                    Location pillarLoc = new Location(world, target.getX(), currentY, target.getZ());
                    TNTPrimed tnt = world.spawn(pillarLoc, TNTPrimed.class);
                    tnt.setFuseTicks(10);
                    tnt.setVelocity(new Vector(0, -0.6, 0));

                    world.spawnParticle(Particle.SONIC_BOOM, pillarLoc, 1);
                    world.spawnParticle(Particle.CAMPFIRE_COSY_SMOKE, pillarLoc, 6, 0.2, 0.2, 0.2, 0.05);
                    currentY -= step;
                }
            }
        }.runTaskTimer(this, 1L, 2L);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return filter(Arrays.asList("nuke", "stab"), args[0]);
        } else if (args.length == 2) {
            return filter(Arrays.asList("give"), args[1]);
        } else if (args.length == 3) {
            return filter(Arrays.asList("1", "4", "16", "64"), args[2]);
        } else if (args.length == 4) {
            return filter(Arrays.asList("5", "10", "15", "20"), args[3]);
        }
        return new ArrayList<>();
    }

    private List<String> filter(List<String> list, String prefix) {
        List<String> result = new ArrayList<>();
        for (String s : list) {
            if (s.toLowerCase().startsWith(prefix.toLowerCase())) {
                result.add(s);
            }
        }
        return result;
    }
}
